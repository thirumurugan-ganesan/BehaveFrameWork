from selenium import webdriver
from browser import Browser
from pages.home_page import HomePage
from pages.common_impl import Common_Impl
from pages.search_results_page import SearchResultsPage

def before_all(context):
    print("===============* B4 all started *===============")
    context.browser = Browser()
    context.home_page = HomePage()
    context.search_results_page = SearchResultsPage()
    context.common_impl_methods = Common_Impl()
    print("===============* B4 all Ends here *===============")

def after_all(context):
    #context.browser.close()
    pass

