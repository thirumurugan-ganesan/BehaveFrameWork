from selenium import webdriver

browser = 'chrome'

chromeDriverExe = 'C:\\behave_test\\TVDotCom_Proj\\features\\utilities\\chromedriver.exe'
geckoDriverExe = 'D:\Behave_Example\geckodriver-v0.26.0-win64\geckodriver.exe'

class Browser(object):
    if(browser== 'firefox'):
        #driver = webdriver.Firefox(executable_path=r'D:\Behave_Example\geckodriver-v0.26.0-win64\geckodriver.exe')
        driver = webdriver.Firefox(executable_path=geckoDriverExe)
        driver.implicitly_wait(30)
        driver.set_page_load_timeout(30)
        driver.maximize_window()
    elif(browser=='chrome'):
        driver= webdriver.Chrome(executable_path=chromeDriverExe)
        driver.maximize_window()
        driver.delete_all_cookies()

    def close(context):
        context.driver.close()
