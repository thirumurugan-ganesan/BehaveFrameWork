from browser import Browser



class Common_Impl(Browser):

    def get_page_title(self):
        return self.driver.title
