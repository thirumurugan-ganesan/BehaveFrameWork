from nose.tools import assert_equal, assert_true
from selenium.webdriver.common.by import By
import time


@step('I navigate to the PyPi Home page')
def step_impl(context):
    context.home_page.navigate("https://pypi.python.org/pypi")
    assert_equal(context.home_page.get_page_title(), "PyPI · The Python Package Index")

@step(u'Launch browser and navigate to url "{url}"')
def step_impl(context,url):
    context.home_page.navigate(url)
    time.sleep(6)
    context.home_page.cancel_popup()
    #driver = launch_browser_navigateURL(url)

@step('I search for "{search_term}"')
def step_impl(context, search_term):
    context.home_page.search(search_term)

@step('I am taken to the PyPi Search Results page')
def step_impl(context):
    assert_equal(context.search_results_page.get_page_title(), "Search results · PyPI")

@step('I see a search result "{search_result}"')
def step_impl(context, search_result):
    assert_true(context.search_results_page.find_search_result(search_result))

@step('Verify the home page title "{expected_page_title}"')
def step_impl(context, expected_page_title ):
    actual_page_title = context.home_page.get_page_title
    print("Fios TV.Com page title is : ", actual_page_title)
    #assert_equal(expected_page_title, actual_page_titles)